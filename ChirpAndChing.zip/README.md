# Chirp & Ching - Unity 2D project

Everything from the tutorial, ready to run: all 9 scripts, 7 pixel-art sprites,
jump / coin sound effects, a looping background track, three scenes, UI and button wiring.

## Setup (about 2 minutes)

1. In Unity Hub create a new project: **Unity 6, 2D template** (2D Core or Universal 2D both work). Name it ChirpAndChing.
2. Close Unity, or leave it open. Copy the **Assets** folder from this zip into the project, merging with the existing Assets folder.
3. Switch back to Unity. It imports the files, then the **Chirp and Ching builder runs automatically**
   and creates the MainMenu, Game and Win scenes, the Ground layer, the Coin prefab, and the Build Settings list.
   Wait for the "project built!" message in the Console.
4. Open `Assets/Scenes/MainMenu`, press **Play**.

If the builder does not run, use the top menu: **Chirp and Ching > Build Project (rebuild scenes)**.
You can run it again at any time to reset the scenes to defaults (it overwrites the three scenes).

## Controls
A / D or arrow keys move, Space jumps, Escape pauses (or click PAUSE).

## What goes where
| Tutorial item | Implementation |
|---|---|
| Moving sprites | Bird (`PlayerController`), moving platforms (`MovingPlatform`) - the bird rides them |
| Pause | Escape + PAUSE button (`GameManager`) |
| Saving data | `PlayerPrefs`: BestScore, LastScore |
| Music | AudioSource on the GameManager object (`BackgroundMusic.wav`, loops) |
| Jumping | Space (`PlayerController`) |
| UI | Main menu, pause menu, HUD, win screen |
| Collection | `Coin` (prefab in Assets/Prefabs) |
| Sound effects | Jump.wav, Coin.wav |
| Scene transitions | MainMenu -> Game -> Win |

## Differences from the original tutorial (small improvements)
- `GameInput.cs` works with both the old Input Manager and the new Input System, so no Project Settings change is needed.
- `PlayerController` uses `linearVelocity` on Unity 6 and `velocity` on older versions automatically.
- Falling into a pit respawns the bird on the last solid ground.
- HUD shows `Coins: 5 / 27`.
- Music pauses with the game.

## Troubleshooting
- **Pink/missing text:** the UI uses Unity's built-in legacy font; nothing to import.
- **Bird does not jump:** the Ground layer must be set on platforms (the builder does this) and the Player needs the Player tag (also done).
- **Compile errors after copying:** make sure the project is Unity 2021.3 or newer and the `Unity UI` package is installed (included in 2D templates).
- **Best score reset:** Edit > Clear All PlayerPrefs.
