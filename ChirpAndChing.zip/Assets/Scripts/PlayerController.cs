using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 5f;
    public float jumpForce = 8f;

    [Header("Ground check")]
    public Transform groundCheck;
    public float groundRadius = 0.2f;
    public LayerMask groundLayer;

    [Header("Audio")]
    public AudioSource audioSource;
    public AudioClip jumpSound;

    [Header("Falling")]
    public float fallLimit = -10f;

    private Rigidbody2D rb;
    private bool isGrounded;
    private float moveInput;
    private float platformVelocityX;
    private Vector3 lastSafePosition;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        lastSafePosition = transform.position;
    }

    void Update()
    {
        // Ignore input while the game is paused
        if (Time.timeScale == 0f)
        {
            moveInput = 0f;
            return;
        }

        moveInput = GameInput.Horizontal();

        Collider2D ground = null;
        if (groundCheck != null)
            ground = Physics2D.OverlapCircle(groundCheck.position, groundRadius, groundLayer);

        isGrounded = ground != null;
        platformVelocityX = 0f;

        if (ground != null)
        {
            // Ride moving platforms
            MovingPlatform platform = ground.GetComponentInParent<MovingPlatform>();
            if (platform != null)
                platformVelocityX = platform.Velocity.x;
            else
                lastSafePosition = transform.position;
        }

        if (GameInput.JumpPressed() && isGrounded)
        {
            SetVelocity(new Vector2(GetVelocity().x, jumpForce));

            if (jumpSound != null && audioSource != null)
                audioSource.PlayOneShot(jumpSound);
        }

        if (moveInput != 0)
        {
            transform.localScale = new Vector3(Mathf.Sign(moveInput), 1, 1);
        }

        // Fell into a pit: go back to the last safe ground
        if (transform.position.y < fallLimit)
            Respawn();
    }

    void FixedUpdate()
    {
        SetVelocity(new Vector2(
            moveInput * moveSpeed + platformVelocityX,
            GetVelocity().y
        ));
    }

    void Respawn()
    {
        transform.position = lastSafePosition + Vector3.up * 0.5f;
        SetVelocity(Vector2.zero);
    }

    // Unity 6 renamed Rigidbody2D.velocity to linearVelocity. This works on both.
    Vector2 GetVelocity()
    {
#if UNITY_6000_0_OR_NEWER
        return rb.linearVelocity;
#else
        return rb.velocity;
#endif
    }

    void SetVelocity(Vector2 v)
    {
#if UNITY_6000_0_OR_NEWER
        rb.linearVelocity = v;
#else
        rb.velocity = v;
#endif
    }
}
