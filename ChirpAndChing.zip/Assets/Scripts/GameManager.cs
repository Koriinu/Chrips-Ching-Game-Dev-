using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    public Text coinText;
    public Text bestScoreText;

    public GameObject pausePanel;
    public AudioSource music;

    [Tooltip("Total coins in the level (shown as Coins: 3 / 27). Set to 0 to hide the total.")]
    public int totalCoins = 0;

    private int coins = 0;
    private int bestScore = 0;
    private bool isPaused = false;

    void Awake()
    {
        instance = this;

        bestScore = PlayerPrefs.GetInt("BestScore", 0);

        Time.timeScale = 1f;
    }

    void Start()
    {
        if (pausePanel != null)
            pausePanel.SetActive(false);

        UpdateUI();

        if (music != null)
            music.Play();
    }

    void Update()
    {
        if (GameInput.PausePressed())
        {
            if (isPaused)
                ResumeGame();
            else
                PauseGame();
        }
    }

    public void CollectCoin()
    {
        coins++;

        if (coins > bestScore)
        {
            bestScore = coins;
            PlayerPrefs.SetInt("BestScore", bestScore);
            PlayerPrefs.Save();
        }

        UpdateUI();
    }

    void UpdateUI()
    {
        if (coinText != null)
            coinText.text = "Coins: " + coins + (totalCoins > 0 ? " / " + totalCoins : "");

        if (bestScoreText != null)
            bestScoreText.text = "Best: " + bestScore;
    }

    public void PauseGame()
    {
        isPaused = true;
        Time.timeScale = 0f;

        if (music != null)
            music.Pause();

        if (pausePanel != null)
            pausePanel.SetActive(true);
    }

    public void ResumeGame()
    {
        isPaused = false;
        Time.timeScale = 1f;

        if (music != null)
            music.UnPause();

        if (pausePanel != null)
            pausePanel.SetActive(false);
    }

    public void RestartGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("Game");
    }

    public void WinGame()
    {
        PlayerPrefs.SetInt("LastScore", coins);
        PlayerPrefs.SetInt("LastTotal", totalCoins);
        PlayerPrefs.Save();

        Time.timeScale = 1f;
        SceneManager.LoadScene("Win");
    }

    public void MainMenu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("MainMenu");
    }
}
