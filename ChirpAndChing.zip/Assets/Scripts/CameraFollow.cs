using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public float smooth = 8f;
    public float minX = -3.6f, maxX = 53f;
    public float minY = -0.5f, maxY = 3f;
    public float yOffset = 1f;

    void LateUpdate()
    {
        if (target == null) return;

        float tx = Mathf.Clamp(target.position.x, minX, maxX);
        float ty = Mathf.Clamp(target.position.y + yOffset, minY, maxY);
        float k = 1f - Mathf.Exp(-smooth * Time.unscaledDeltaTime);

        Vector3 p = transform.position;
        p.x = Mathf.Lerp(p.x, tx, k);
        p.y = Mathf.Lerp(p.y, ty, k);
        transform.position = p;
    }
}
