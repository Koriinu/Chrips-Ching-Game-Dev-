using UnityEngine;

public class Coin : MonoBehaviour
{
    public AudioClip collectSound;
    public float spinSpeed = 3f;
    public float bobHeight = 0.1f;

    private Vector3 startPosition;
    private float offset;
    private bool collected;

    void Start()
    {
        startPosition = transform.position;
        offset = Random.value * 6.28f;
    }

    void Update()
    {
        float t = Time.time * spinSpeed + offset;
        transform.localScale = new Vector3(Mathf.Abs(Mathf.Cos(t)) * 0.8f + 0.2f, 1f, 1f);
        transform.position = startPosition + Vector3.up * Mathf.Sin(t * 1.3f) * bobHeight;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (collected) return;

        if (other.CompareTag("Player"))
        {
            collected = true;

            if (GameManager.instance != null)
                GameManager.instance.CollectCoin();

            if (collectSound != null)
            {
                AudioSource.PlayClipAtPoint(collectSound, transform.position);
            }

            Destroy(gameObject);
        }
    }
}
