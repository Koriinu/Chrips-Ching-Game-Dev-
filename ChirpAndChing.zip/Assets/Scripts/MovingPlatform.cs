using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class MovingPlatform : MonoBehaviour
{
    public float moveDistance = 3f;
    public float moveSpeed = 2f;
    public float phase = 0f;

    /// <summary>Current velocity, read by the player so the bird rides along.</summary>
    public Vector2 Velocity { get; private set; }

    private Vector2 startPosition;
    private Rigidbody2D rb;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.bodyType = RigidbodyType2D.Kinematic;
        startPosition = transform.position;
    }

    void FixedUpdate()
    {
        float t = Time.fixedTime * moveSpeed + phase;
        Vector2 target = startPosition + Vector2.right * Mathf.Sin(t) * moveDistance;
        Velocity = new Vector2(Mathf.Cos(t) * moveSpeed * moveDistance, 0f);
        rb.MovePosition(target);
    }
}
