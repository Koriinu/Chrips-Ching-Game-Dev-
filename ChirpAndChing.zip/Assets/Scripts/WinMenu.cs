using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class WinMenu : MonoBehaviour
{
    public Text finalScoreText;

    void Start()
    {
        int score = PlayerPrefs.GetInt("LastScore", 0);
        int total = PlayerPrefs.GetInt("LastTotal", 0);

        if (finalScoreText != null)
            finalScoreText.text = "Coins Collected: " + score + (total > 0 ? " / " + total : "");
    }

    public void PlayAgain()
    {
        SceneManager.LoadScene("Game");
    }

    public void MainMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }
}
