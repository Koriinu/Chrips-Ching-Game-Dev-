using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MenuController : MonoBehaviour
{
    public Text bestScoreText;

    void Start()
    {
        Time.timeScale = 1f;

        if (bestScoreText != null)
            bestScoreText.text = "Best: " + PlayerPrefs.GetInt("BestScore", 0) + " coins";
    }

    public void StartGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("Game");
    }

    public void OpenMenu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("MainMenu");
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}
