using System.IO;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// Builds the whole Chirp and Ching project: sprite import settings, the Ground layer,
/// the Coin prefab, the MainMenu / Game / Win scenes, all UI, button wiring and build settings.
/// Runs automatically the first time the project opens, or any time from the
/// "Chirp and Ching" menu at the top of the editor.
/// </summary>
public static class ChirpAndChingBuilder
{
    const string SpriteDir = "Assets/Sprites/";
    const string AudioDir = "Assets/Audio/";
    const string SceneDir = "Assets/Scenes/";

    static readonly Color Sky = new Color(0.38f, 0.70f, 0.96f);
    static readonly Color Gold = new Color(1f, 0.82f, 0.2f);
    static readonly Color Green = new Color(0.25f, 0.72f, 0.35f);
    static readonly Color Orange = new Color(0.95f, 0.60f, 0.15f);
    static readonly Color Red = new Color(0.85f, 0.30f, 0.30f);

    [MenuItem("Chirp and Ching/Build Project (rebuild scenes)")]
    public static void BuildMenu()
    {
        BuildAll();
    }

    public static void BuildAll()
    {
        AssetDatabase.Refresh();
        Directory.CreateDirectory("Assets/Scenes");
        Directory.CreateDirectory("Assets/Prefabs");
        AssetDatabase.Refresh();

        string[] sprites = { "bird", "grass", "dirt", "mover", "coin", "flag", "cloud" };
        foreach (string s in sprites) ConfigureSprite(SpriteDir + s + ".png");

        int groundLayer = EnsureLayer("Ground");
        PhysicsMaterial2D noFriction = CreateNoFriction();

        PlayerSettings.productName = "Chirp and Ching";

        BuildMainMenu();
        BuildGame(groundLayer, noFriction);
        BuildWin();

        EditorBuildSettings.scenes = new[]
        {
            new EditorBuildSettingsScene(SceneDir + "MainMenu.unity", true),
            new EditorBuildSettingsScene(SceneDir + "Game.unity", true),
            new EditorBuildSettingsScene(SceneDir + "Win.unity", true),
        };

        AssetDatabase.SaveAssets();
        EditorSceneManager.OpenScene(SceneDir + "MainMenu.unity");
        Debug.Log("Chirp and Ching: project built! Open the MainMenu scene and press Play.");
    }

    // ------------------------------------------------------------------
    // Asset setup
    // ------------------------------------------------------------------

    static void ConfigureSprite(string path)
    {
        TextureImporter ti = AssetImporter.GetAtPath(path) as TextureImporter;
        if (ti == null) { Debug.LogWarning("Missing sprite: " + path); return; }

        ti.textureType = TextureImporterType.Sprite;
        ti.spriteImportMode = SpriteImportMode.Single;
        ti.spritePixelsPerUnit = 16;
        ti.filterMode = FilterMode.Point;
        ti.mipmapEnabled = false;
        ti.alphaIsTransparency = true;
        ti.textureCompression = TextureImporterCompression.Uncompressed;

        // Full Rect mesh is required for tiled sprites (platforms)
        TextureImporterSettings settings = new TextureImporterSettings();
        ti.ReadTextureSettings(settings);
        settings.textureType = TextureImporterType.Sprite;
        settings.spriteMode = (int)SpriteImportMode.Single;
        settings.spritePixelsPerUnit = 16;
        settings.filterMode = FilterMode.Point;
        settings.mipmapEnabled = false;
        settings.spriteMeshType = SpriteMeshType.FullRect;
        ti.SetTextureSettings(settings);

        ti.SaveAndReimport();
    }

    static int EnsureLayer(string layerName)
    {
        int existing = LayerMask.NameToLayer(layerName);
        if (existing != -1) return existing;

        Object[] assets = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/TagManager.asset");
        if (assets == null || assets.Length == 0)
        {
            Debug.LogError("Could not open TagManager. Create a layer called Ground manually.");
            return 0;
        }

        SerializedObject tagManager = new SerializedObject(assets[0]);
        SerializedProperty layers = tagManager.FindProperty("layers");
        for (int i = 8; i < layers.arraySize; i++)
        {
            SerializedProperty sp = layers.GetArrayElementAtIndex(i);
            if (string.IsNullOrEmpty(sp.stringValue))
            {
                sp.stringValue = layerName;
                tagManager.ApplyModifiedProperties();
                return i;
            }
        }
        Debug.LogError("No free layer slots for Ground.");
        return 0;
    }

    static PhysicsMaterial2D CreateNoFriction()
    {
        string path = "Assets/NoFriction.physicsMaterial2D";
        PhysicsMaterial2D existing = AssetDatabase.LoadAssetAtPath<PhysicsMaterial2D>(path);
        if (existing != null) return existing;

        PhysicsMaterial2D mat = new PhysicsMaterial2D("NoFriction");
        mat.friction = 0f;
        mat.bounciness = 0f;
        AssetDatabase.CreateAsset(mat, path);
        return mat;
    }

    static Sprite LoadSprite(string name)
    {
        Sprite s = AssetDatabase.LoadAssetAtPath<Sprite>(SpriteDir + name + ".png");
        if (s == null) Debug.LogWarning("Could not load sprite " + name);
        return s;
    }

    static AudioClip LoadClip(string file)
    {
        AudioClip c = AssetDatabase.LoadAssetAtPath<AudioClip>(AudioDir + file);
        if (c == null) Debug.LogWarning("Could not load audio " + file);
        return c;
    }

    // ------------------------------------------------------------------
    // Shared scene helpers
    // ------------------------------------------------------------------

    static Camera MakeCamera()
    {
        GameObject go = new GameObject("Main Camera", typeof(Camera), typeof(AudioListener));
        go.tag = "MainCamera";
        Camera cam = go.GetComponent<Camera>();
        cam.orthographic = true;
        cam.orthographicSize = 5f;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = Sky;
        go.transform.position = new Vector3(0, 0, -10);
        return cam;
    }

    static SpriteRenderer AddSprite(GameObject go, string spriteName, int order)
    {
        SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = LoadSprite(spriteName);
        sr.sortingOrder = order;
        return sr;
    }

    static void MakeEventSystem()
    {
        GameObject es = new GameObject("EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
        es.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
#else
        es.AddComponent<StandaloneInputModule>();
#endif
    }

    static Font UIFont()
    {
#if UNITY_2022_2_OR_NEWER
        return Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
        return Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
    }

    static Transform MakeCanvas()
    {
        GameObject go = new GameObject("Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        Canvas c = go.GetComponent<Canvas>();
        c.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler s = go.GetComponent<CanvasScaler>();
        s.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        s.referenceResolution = new Vector2(1920, 1080);
        s.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        s.matchWidthOrHeight = 0.5f;
        return go.transform;
    }

    static Image MakeFill(Transform parent, string name, Color color)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        RectTransform rt = (RectTransform)go.transform;
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero;
        rt.offsetMax = Vector2.zero;
        Image img = go.GetComponent<Image>();
        img.color = color;
        img.raycastTarget = true;
        return img;
    }

    static Image MakeImage(Transform parent, string name, Color color, Vector2 anchor, Vector2 pos, Vector2 size)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        RectTransform rt = (RectTransform)go.transform;
        rt.anchorMin = anchor; rt.anchorMax = anchor; rt.pivot = anchor;
        rt.anchoredPosition = pos; rt.sizeDelta = size;
        Image img = go.GetComponent<Image>();
        img.color = color;
        img.raycastTarget = false;
        return img;
    }

    static Text MakeText(Transform parent, string name, string content, int size, TextAnchor align,
                         Color color, Vector2 anchor, Vector2 pos, Vector2 box)
    {
        GameObject go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        RectTransform rt = (RectTransform)go.transform;
        rt.anchorMin = anchor; rt.anchorMax = anchor; rt.pivot = anchor;
        rt.anchoredPosition = pos; rt.sizeDelta = box;

        Text t = go.AddComponent<Text>();
        t.font = UIFont();
        t.text = content;
        t.fontSize = size;
        t.fontStyle = FontStyle.Bold;
        t.alignment = align;
        t.color = color;
        t.horizontalOverflow = HorizontalWrapMode.Overflow;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;

        Outline o = go.AddComponent<Outline>();
        o.effectColor = new Color(0f, 0f, 0f, 0.8f);
        o.effectDistance = new Vector2(3f, -3f);
        return t;
    }

    static Button MakeButton(Transform parent, string name, string label, Vector2 anchor,
                             Vector2 pos, Vector2 size, Color color, int fontSize = 56)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
        go.transform.SetParent(parent, false);
        RectTransform rt = (RectTransform)go.transform;
        rt.anchorMin = anchor; rt.anchorMax = anchor; rt.pivot = anchor;
        rt.anchoredPosition = pos; rt.sizeDelta = size;

        Image img = go.GetComponent<Image>();
        img.color = color;

        Button btn = go.GetComponent<Button>();
        btn.targetGraphic = img;
        ColorBlock cb = btn.colors;
        cb.normalColor = Color.white;
        cb.highlightedColor = new Color(0.9f, 0.9f, 0.9f, 1f);
        cb.pressedColor = new Color(0.7f, 0.7f, 0.7f, 1f);
        cb.selectedColor = Color.white;
        btn.colors = cb;

        MakeText(go.transform, "Label", label, fontSize, TextAnchor.MiddleCenter, Color.white,
                 new Vector2(0.5f, 0.5f), Vector2.zero, size);
        return btn;
    }

    static void MakeBirdImage(Transform parent, Vector2 pos, float size)
    {
        GameObject go = new GameObject("BirdImage", typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        RectTransform rt = (RectTransform)go.transform;
        rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos;
        rt.sizeDelta = new Vector2(size, size);
        Image img = go.GetComponent<Image>();
        img.sprite = LoadSprite("bird");
        img.preserveAspect = true;
        img.raycastTarget = false;
    }

    static void MakeGroundStrip(Transform parent)
    {
        MakeImage(parent, "GroundStrip", new Color(0.33f, 0.69f, 0.2f), new Vector2(0.5f, 0f),
                  Vector2.zero, new Vector2(4000f, 110f));
        MakeImage(parent, "GroundDirt", new Color(0.53f, 0.34f, 0.2f), new Vector2(0.5f, 0f),
                  Vector2.zero, new Vector2(4000f, 70f));
    }

    // ------------------------------------------------------------------
    // MainMenu scene
    // ------------------------------------------------------------------

    static void BuildMainMenu()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        MakeCamera();
        MakeEventSystem();

        Transform canvas = MakeCanvas();
        MakeGroundStrip(canvas);

        MakeText(canvas, "GameTitle", "CHIRP & CHING", 130, TextAnchor.MiddleCenter, Gold,
                 new Vector2(0.5f, 0.5f), new Vector2(0, 340), new Vector2(1400, 160));
        MakeText(canvas, "Subtitle", "A tiny pixel platformer", 44, TextAnchor.MiddleCenter, Color.white,
                 new Vector2(0.5f, 0.5f), new Vector2(0, 250), new Vector2(1000, 60));
        MakeBirdImage(canvas, new Vector2(0, 90), 260);

        Button play = MakeButton(canvas, "PlayButton", "PLAY GAME", new Vector2(0.5f, 0.5f),
                                 new Vector2(0, -110), new Vector2(520, 110), Green);
        Button quit = MakeButton(canvas, "QuitButton", "QUIT", new Vector2(0.5f, 0.5f),
                                 new Vector2(0, -250), new Vector2(520, 110), Red);

        Text best = MakeText(canvas, "BestScoreText", "Best: 0 coins", 40, TextAnchor.MiddleCenter, Color.white,
                             new Vector2(0.5f, 0.5f), new Vector2(0, -360), new Vector2(800, 60));
        MakeText(canvas, "Controls", "A / D or arrows: move     SPACE: jump     ESC: pause", 32,
                 TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 0f), new Vector2(0, 150), new Vector2(1500, 50));

        GameObject mcObj = new GameObject("MenuController");
        MenuController mc = mcObj.AddComponent<MenuController>();
        mc.bestScoreText = best;

        UnityEventTools.AddPersistentListener(play.onClick, mc.StartGame);
        UnityEventTools.AddPersistentListener(quit.onClick, mc.QuitGame);

        EditorSceneManager.SaveScene(scene, SceneDir + "MainMenu.unity");
    }

    // ------------------------------------------------------------------
    // Win scene
    // ------------------------------------------------------------------

    static void BuildWin()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        MakeCamera();
        MakeEventSystem();

        Transform canvas = MakeCanvas();
        MakeGroundStrip(canvas);

        MakeText(canvas, "WinText", "YOU WIN!", 150, TextAnchor.MiddleCenter, Gold,
                 new Vector2(0.5f, 0.5f), new Vector2(0, 330), new Vector2(1400, 180));
        MakeText(canvas, "Subtitle", "You collected all those coins!", 48, TextAnchor.MiddleCenter, Color.white,
                 new Vector2(0.5f, 0.5f), new Vector2(0, 220), new Vector2(1400, 70));
        MakeBirdImage(canvas, new Vector2(0, 80), 220);
        Text finalScore = MakeText(canvas, "FinalScoreText", "Coins Collected: 0", 56, TextAnchor.MiddleCenter, Color.white,
                                   new Vector2(0.5f, 0.5f), new Vector2(0, -60), new Vector2(1200, 80));

        Button again = MakeButton(canvas, "PlayAgainButton", "PLAY AGAIN", new Vector2(0.5f, 0.5f),
                                  new Vector2(0, -190), new Vector2(520, 110), Green);
        Button menu = MakeButton(canvas, "MainMenuButton", "MAIN MENU", new Vector2(0.5f, 0.5f),
                                 new Vector2(0, -330), new Vector2(520, 110), Orange);

        GameObject wmObj = new GameObject("WinMenu");
        WinMenu wm = wmObj.AddComponent<WinMenu>();
        wm.finalScoreText = finalScore;

        UnityEventTools.AddPersistentListener(again.onClick, wm.PlayAgain);
        UnityEventTools.AddPersistentListener(menu.onClick, wm.MainMenu);

        EditorSceneManager.SaveScene(scene, SceneDir + "Win.unity");
    }

    // ------------------------------------------------------------------
    // Game scene
    // ------------------------------------------------------------------

    static GameObject MakeBlock(string name, Transform parent, float centerX, float topY, float width, int rows,
                                int layer, string topSprite, string bodySprite)
    {
        float height = rows;
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.transform.position = new Vector3(centerX, topY - height / 2f, 0f);
        go.layer = layer;

        BoxCollider2D col = go.AddComponent<BoxCollider2D>();
        col.size = new Vector2(width, height);

        for (int r = 0; r < rows; r++)
        {
            GameObject row = new GameObject(r == 0 ? "Top" : "Body" + r);
            row.transform.SetParent(go.transform, false);
            row.transform.localPosition = new Vector3(0f, height / 2f - 0.5f - r, 0f);
            row.layer = layer;
            SpriteRenderer sr = AddSprite(row, r == 0 ? topSprite : bodySprite, 0);
            sr.drawMode = SpriteDrawMode.Tiled;
            sr.size = new Vector2(width, 1f);
        }
        return go;
    }

    static void MakeStaticBlock(string name, Transform parent, float centerX, float topY, float width, int rows, int layer)
    {
        MakeBlock(name, parent, centerX, topY, width, rows, layer, "grass", "dirt");
    }

    static void MakeMovingBlock(string name, Transform parent, float centerX, float topY, float width,
                                int layer, float distance, float speed, float phase)
    {
        GameObject go = MakeBlock(name, parent, centerX, topY, width, 1, layer, "mover", "mover");
        Rigidbody2D rb = go.AddComponent<Rigidbody2D>();
        rb.bodyType = RigidbodyType2D.Kinematic;
        rb.interpolation = RigidbodyInterpolation2D.Interpolate;
        MovingPlatform mp = go.AddComponent<MovingPlatform>();
        mp.moveDistance = distance;
        mp.moveSpeed = speed;
        mp.phase = phase;
    }

    static GameObject MakeCoinPrefab(AudioClip sound)
    {
        GameObject go = new GameObject("Coin");
        AddSprite(go, "coin", 1);
        CircleCollider2D col = go.AddComponent<CircleCollider2D>();
        col.radius = 0.4f;
        col.isTrigger = true;
        Coin coin = go.AddComponent<Coin>();
        coin.collectSound = sound;
        GameObject prefab = PrefabUtility.SaveAsPrefabAsset(go, "Assets/Prefabs/Coin.prefab");
        UnityEngine.Object.DestroyImmediate(go);
        return prefab;
    }

    static GameObject MakePlayer(int groundLayer, PhysicsMaterial2D noFriction, AudioClip jump)
    {
        GameObject p = new GameObject("Player");
        p.tag = "Player";
        p.transform.position = new Vector3(-8f, -3.4f, 0f);
        AddSprite(p, "bird", 3);

        Rigidbody2D rb = p.AddComponent<Rigidbody2D>();
        rb.gravityScale = 2f;
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;
        rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        rb.interpolation = RigidbodyInterpolation2D.Interpolate;

        BoxCollider2D col = p.AddComponent<BoxCollider2D>();
        col.size = new Vector2(0.7f, 0.9f);
        col.offset = new Vector2(0f, -0.05f);
        col.sharedMaterial = noFriction;

        AudioSource audio = p.AddComponent<AudioSource>();
        audio.playOnAwake = false;

        GameObject gc = new GameObject("GroundCheck");
        gc.transform.SetParent(p.transform, false);
        gc.transform.localPosition = new Vector3(0f, -0.45f, 0f);

        PlayerController pc = p.AddComponent<PlayerController>();
        pc.groundCheck = gc.transform;
        pc.groundLayer = 1 << groundLayer;
        pc.audioSource = audio;
        pc.jumpSound = jump;
        return p;
    }

    static void BuildGame(int groundLayer, PhysicsMaterial2D noFriction)
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        AudioClip jumpClip = LoadClip("Jump.wav");
        AudioClip coinClip = LoadClip("Coin.wav");
        AudioClip musicClip = LoadClip("BackgroundMusic.wav");

        Camera cam = MakeCamera();
        MakeEventSystem();

        // Background clouds
        Transform env = new GameObject("Environment").transform;
        float[,] clouds = { { -9, 3.2f, 3 }, { 0, 2.2f, 2.5f }, { 10, 3.6f, 3 }, { 20, 2.4f, 2 }, { 31, 3.4f, 3 },
                            { 42, 2.6f, 2.5f }, { 52, 3.5f, 3 }, { 60, 2.3f, 2 } };
        for (int i = 0; i < clouds.GetLength(0); i++)
        {
            GameObject c = new GameObject("Cloud" + (i + 1));
            c.transform.SetParent(env, false);
            c.transform.position = new Vector3(clouds[i, 0], clouds[i, 1], 0f);
            c.transform.localScale = Vector3.one * clouds[i, 2];
            AddSprite(c, "cloud", -10);
        }

        // Level geometry: ground top is y = -4. A jump reaches about 1.6 units high and 4 units across.
        Transform level = new GameObject("Level").transform;
        MakeStaticBlock("Ground A", level, -3f, -4f, 18f, 3, groundLayer);      // x -12 .. 6
        MakeStaticBlock("Platform 1", level, 9.5f, -3f, 3f, 1, groundLayer);    // x 8 .. 11
        MakeMovingBlock("Moving Platform 1", level, 16f, -2f, 3f, groundLayer, 2.5f, 1.2f, 0f);
        MakeStaticBlock("Platform 2", level, 22.5f, -3f, 3f, 1, groundLayer);   // x 21 .. 24
        MakeStaticBlock("Platform 3", level, 27.5f, -2f, 3f, 1, groundLayer);   // x 26 .. 29
        MakeMovingBlock("Moving Platform 2", level, 34f, -2f, 3f, groundLayer, 2f, 1.0f, 1.5f);
        MakeStaticBlock("Ground B", level, 50f, -4f, 24f, 3, groundLayer);      // x 38 .. 62
        MakeStaticBlock("Step 1", level, 43f, -3f, 2f, 1, groundLayer);
        MakeStaticBlock("Step 2", level, 45f, -2f, 2f, 2, groundLayer);
        MakeStaticBlock("Step 3", level, 47f, -1f, 2f, 3, groundLayer);
        MakeStaticBlock("Floating Platform", level, 52f, -1f, 3f, 1, groundLayer);

        // Invisible walls so the bird can't leave the level
        foreach (float wx in new float[] { -12.5f, 62.5f })
        {
            GameObject wall = new GameObject("Wall");
            wall.transform.SetParent(level, false);
            wall.transform.position = new Vector3(wx, 0f, 0f);
            BoxCollider2D wc = wall.AddComponent<BoxCollider2D>();
            wc.size = new Vector2(1f, 40f);
            wc.sharedMaterial = noFriction;
        }

        // Coins
        GameObject coinPrefab = MakeCoinPrefab(coinClip);
        Transform coins = new GameObject("Coins").transform;
        float[,] coinPos =
        {
            { -5, -3 }, { -3, -3 }, { -1, -3 }, { 1, -3 }, { 3, -3 }, { 5.2f, -2.2f }, { 7, -2f },
            { 9, -1.8f }, { 10, -1.8f }, { 12.5f, -0.8f }, { 16, -0.8f }, { 19.2f, -0.8f },
            { 21.8f, -1.8f }, { 22.5f, -1.8f }, { 23.2f, -1.8f }, { 27, -0.8f }, { 28, -0.8f }, { 34, -0.8f },
            { 39, -3 }, { 40.5f, -3 }, { 43, -1.8f }, { 45, -0.8f }, { 47, 0.2f }, { 49.3f, 0.8f },
            { 52, 0.2f }, { 55, -3 }, { 56.5f, -3 },
        };
        int coinCount = coinPos.GetLength(0);
        for (int i = 0; i < coinCount; i++)
        {
            GameObject c = (GameObject)PrefabUtility.InstantiatePrefab(coinPrefab);
            c.name = "Coin " + (i + 1);
            c.transform.SetParent(coins, false);
            c.transform.position = new Vector3(coinPos[i, 0], coinPos[i, 1], 0f);
        }

        // Finish line
        GameObject finish = new GameObject("FinishLine");
        finish.transform.position = new Vector3(58f, -3f, 0f);
        AddSprite(finish, "flag", 1);
        BoxCollider2D fc = finish.AddComponent<BoxCollider2D>();
        fc.size = new Vector2(1.5f, 3f);
        fc.offset = new Vector2(0f, 0.5f);
        fc.isTrigger = true;
        finish.AddComponent<FinishLine>();

        // Player + camera
        GameObject player = MakePlayer(groundLayer, noFriction, jumpClip);
        CameraFollow follow = cam.gameObject.AddComponent<CameraFollow>();
        follow.target = player.transform;
        follow.minX = -3.6f;
        follow.maxX = 53.5f;

        // UI
        Transform canvas = MakeCanvas();
        Transform hud = new GameObject("HUD", typeof(RectTransform)).transform;
        hud.SetParent(canvas, false);
        RectTransform hudRt = (RectTransform)hud;
        hudRt.anchorMin = Vector2.zero; hudRt.anchorMax = Vector2.one;
        hudRt.offsetMin = Vector2.zero; hudRt.offsetMax = Vector2.zero;

        Text coinText = MakeText(hud, "CoinText", "Coins: 0", 60, TextAnchor.UpperLeft, Gold,
                                 new Vector2(0f, 1f), new Vector2(40, -30), new Vector2(700, 80));
        Text bestText = MakeText(hud, "BestScoreText", "Best: 0", 40, TextAnchor.UpperLeft, Color.white,
                                 new Vector2(0f, 1f), new Vector2(40, -105), new Vector2(500, 60));
        MakeText(hud, "HintText", "A / D to move  -  SPACE to jump  -  ESC to pause", 32, TextAnchor.LowerCenter,
                 Color.white, new Vector2(0.5f, 0f), new Vector2(0, 30), new Vector2(1400, 50));
        Button pauseBtn = MakeButton(hud, "PauseButton", "PAUSE", new Vector2(1f, 1f),
                                     new Vector2(-40, -30), new Vector2(220, 80), Orange, 40);

        // Pause panel (hidden at start)
        Image panelImg = MakeFill(canvas, "PausePanel", new Color(0f, 0f, 0f, 0.72f));
        GameObject panel = panelImg.gameObject;
        MakeText(panel.transform, "PausedText", "PAUSED", 120, TextAnchor.MiddleCenter, Gold,
                 new Vector2(0.5f, 0.5f), new Vector2(0, 260), new Vector2(1000, 150));
        Button resumeBtn = MakeButton(panel.transform, "ResumeButton", "RESUME", new Vector2(0.5f, 0.5f),
                                      new Vector2(0, 60), new Vector2(520, 110), Green);
        Button restartBtn = MakeButton(panel.transform, "RestartButton", "RESTART", new Vector2(0.5f, 0.5f),
                                       new Vector2(0, -80), new Vector2(520, 110), Orange);
        Button menuBtn = MakeButton(panel.transform, "MainMenuButton", "MAIN MENU", new Vector2(0.5f, 0.5f),
                                    new Vector2(0, -220), new Vector2(520, 110), Red);

        // Game manager (score, saving, music, pause)
        GameObject gmObj = new GameObject("GameManager");
        GameManager gm = gmObj.AddComponent<GameManager>();
        AudioSource music = gmObj.AddComponent<AudioSource>();
        music.clip = musicClip;
        music.loop = true;
        music.playOnAwake = false;
        music.volume = 0.5f;

        gm.coinText = coinText;
        gm.bestScoreText = bestText;
        gm.pausePanel = panel;
        gm.music = music;
        gm.totalCoins = coinCount;

        UnityEventTools.AddPersistentListener(pauseBtn.onClick, gm.PauseGame);
        UnityEventTools.AddPersistentListener(resumeBtn.onClick, gm.ResumeGame);
        UnityEventTools.AddPersistentListener(restartBtn.onClick, gm.RestartGame);
        UnityEventTools.AddPersistentListener(menuBtn.onClick, gm.MainMenu);

        panel.SetActive(false);

        EditorSceneManager.SaveScene(scene, SceneDir + "Game.unity");
    }
}

/// <summary>Builds everything automatically the first time the project is opened.</summary>
[InitializeOnLoad]
static class ChirpAndChingAutoBuild
{
    static ChirpAndChingAutoBuild()
    {
        EditorApplication.delayCall += TryBuild;
    }

    static void TryBuild()
    {
        if (EditorApplication.isCompiling || EditorApplication.isUpdating)
        {
            EditorApplication.delayCall += TryBuild;
            return;
        }
        if (EditorApplication.isPlayingOrWillChangePlaymode || BuildPipeline.isBuildingPlayer) return;

        if (!File.Exists("Assets/Scenes/Game.unity") || !File.Exists("Assets/Scenes/MainMenu.unity")
            || !File.Exists("Assets/Scenes/Win.unity"))
        {
            ChirpAndChingBuilder.BuildAll();
        }
    }
}
